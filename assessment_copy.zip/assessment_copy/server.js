const express = require('express');
var bodyParser = require('body-parser');

const app = express();

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.use(express.static(__dirname + "/src"));
// router(app);
app.listen(3000,() => {
    console.log('listening on 3000')
})