var restaurant_app = angular.module('restaurant_module',['ngRoute','ngTable','ui.bootstrap']);


restaurant_app.config(function($routeProvider){
    
    $routeProvider.when('/',{
        templateUrl: 'templates/view_list.html',
        controller: 'view_list_controller'
    })
});

restaurant_app.controller('view_list_controller',['$rootScope','$http','$scope','NgTableParams','$uibModal','$sce',function($rootScope,$http,$scope,NgTableParams,$uibModal,$sce){
    var count = 0;
    
    $scope.country_array = [];
    $scope.per_page = 25;

    $scope.getNumber = function(num) {
        return new Array(num);   
    }

    $scope.page_number;

    $scope.btn_click = () => {
        $scope.restaurant_data = '';
        var url = "http://opentable.herokuapp.com/api/restaurants?city=" + $scope.user_city + "&per_page=" + $scope.per_page + "&page=1";
        url = $sce.trustAsResourceUrl(url);
        if($scope.user_city){
            $http.get(url)
            .then((res) => {
                console.log(res)
                if(res.data.total_entries > 0){
                    $scope.restaurant_data = res;
                    $scope.total_entries = res.data.total_entries;
                    $scope.current_page = res.data.current_page;
                    $scope.pages = Math.ceil($scope.total_entries/$scope.per_page);
                    $scope.tableParams = new NgTableParams(
                    {
                        count:5
                    },
                    {
                        dataset :  res.data.restaurants,
                        counts: []
                    })
                }
            })
                // $scope.country_array.push(res.data.countries);
                // console.log($scope.country_array)
            .catch( (err) => {
                console.log(err)
            });
        }
        
    }

    $scope.change_page = (page) =>{
        // console.log($scope);
        $scope.restaurant_data = '';
        var url = "http://opentable.herokuapp.com/api/restaurants?city=" + $scope.user_city + "&per_page=" + $scope.per_page + "&page=" + page;
        url = $sce.trustAsResourceUrl(url);
        if($scope.user_city){
            $http.get(url)
            .then((res) => {
                console.log(res)
                if(res.data.total_entries > 0){
                    $scope.restaurant_data = res;
                    $scope.total_entries = res.data.total_entries;
                    $scope.current_page = res.data.current_page;

                    $scope.tableParams = new NgTableParams(
                    {
                        count:5
                    },
                    {
                        dataset :  res.data.restaurants,
                        counts: []
                    })
                }
            })
            .catch( (err) => {
                console.log(err)
            });
        }
    }
    
}]);