1. I spent 3 hours on writing the code. If I had more time, I would have added sorting to all fields for better drill down results. I would have added Google Maps for each selected result that would have displayed information like distance from current location, etc.

2. Since I used AngularJS for this assignment, I tried adding ES6 features that offers a variety of features. For example, the double arrow function. 

Ex. $scope.btn_click = () => { };

3. Tracking down performance issues in production can take a long amount of time. Two fastest ways of tracking them: 
	1)Look at DB queries. Add Indexing. 
		-> We take a look at where exactly the problem is on the front end UI. I would then see the appropriate database query that is being used and perform indexing if not already done so.
    2) Check for Load Balancing of Servers
		-> I have personally faced this issue at my previous company. To fix it, we used AWS as the Cloud Computing Services. It provided us with Load Balancing services that handle the server load for us. 
	
4.  I would personally add the option of displaying all restaurants in one call instead of changing the current_page value every single time. 

5.  {
	   "name": "Ramit Sanan",
	   "age": "26",
	   "nickname" : "Ram",
	   "known_as" : "Full Stack Web Developer",
	   "hobbies": {
		  "hobby 1": "Badminton",
		  "hobby 2": "Tennis",
		  "hobby 3": "Piano"
	   },
	   "schools_attended" : {
		  "high_school" : "Kipling CI"
		  "university"  : "Ryerson University"
	   },
	   "ramit_now" : {
		  "position" : "Full Stack Web Developer", 
		  "aspirations" : {
		      "1" : "MBA degree"
			  "2" : "Buy a new house"
		  }
	   }
	   "ramit_2025" : {
		   "position" : "Project Manager", 
		   "cars" : {
			  "1" : "Mercedes Benz GLC 63s coupe",
			  "2" : "Tesla Model S P100D"
		   }
	   }
	}